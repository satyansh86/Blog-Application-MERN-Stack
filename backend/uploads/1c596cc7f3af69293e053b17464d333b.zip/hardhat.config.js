require("@nomicfoundation/hardhat-toolbox");

/** @type import('hardhat/config').HardhatUserConfig */
module.exports = {
  solidity: "0.8.27",
  networks: {
    ganache: {
      url: "http://127.0.0.1:7545",
      accounts: ["0x1c5e2edae22366c25b0f3a794d3cede0b7df47a107b2da41a2bb56e0a3883163"]
    }
  }
};
